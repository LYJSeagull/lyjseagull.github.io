#pragma once
#include <qopenglshaderprogram.h> //shader
#include <qopenglvertexarrayobject.h> //VAO
#include <qopenglbuffer.h>// VBO,EBO
#include <qopenglfunctions_4_5_core.h>//openglFuncs

class Model
{
public:
	Model(QOpenGLFunctions_4_5_Core* openglFuncs = nullptr);
	~Model();

	void Draw(QOpenGLShaderProgram &shader);

private:
	//�������ݣ�����ֵ��[-1,1]֮�䣩
	float vertices[18] = {
		-0.5f,-0.5f,0.0f, 1.0f, 0.0f,0.0f,
		0.5f,-0.5f,0.0f,  1.0f, 0.0f,0.0f,
		0.0f,0.5f,0.0f,  1.0f, 0.0f,0.0f,
	};

	unsigned int indices[3] = { 0,1,2 };

private:
	QOpenGLFunctions_4_5_Core* m_glFunc{ nullptr };
	QOpenGLBuffer m_VBO,m_EBO;
	QOpenGLVertexArrayObject m_VAO;
};
