/********************************************************************************
** Form generated from reading UI file 'MainWindow.ui'
**
** Created by: Qt User Interface Compiler version 6.5.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QWidget>
#include "glview.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindowClass
{
public:
    QAction *action_drawLines;
    QAction *action_clear;
    QAction *action_undo;
    QAction *action_selectLine;
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    GLView *openGLWidget;
    QMenuBar *menuBar;

    void setupUi(QMainWindow *MainWindowClass)
    {
        if (MainWindowClass->objectName().isEmpty())
            MainWindowClass->setObjectName("MainWindowClass");
        MainWindowClass->resize(699, 486);
        action_drawLines = new QAction(MainWindowClass);
        action_drawLines->setObjectName("action_drawLines");
        action_drawLines->setMenuRole(QAction::NoRole);
        action_clear = new QAction(MainWindowClass);
        action_clear->setObjectName("action_clear");
        action_clear->setMenuRole(QAction::NoRole);
        action_undo = new QAction(MainWindowClass);
        action_undo->setObjectName("action_undo");
        action_undo->setMenuRole(QAction::NoRole);
        action_selectLine = new QAction(MainWindowClass);
        action_selectLine->setObjectName("action_selectLine");
        action_selectLine->setMenuRole(QAction::NoRole);
        centralWidget = new QWidget(MainWindowClass);
        centralWidget->setObjectName("centralWidget");
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(0);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName("gridLayout");
        gridLayout->setContentsMargins(0, 0, 0, 0);
        openGLWidget = new GLView(centralWidget);
        openGLWidget->setObjectName("openGLWidget");

        gridLayout->addWidget(openGLWidget, 0, 0, 1, 1);

        MainWindowClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindowClass);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 699, 21));
        MainWindowClass->setMenuBar(menuBar);

        retranslateUi(MainWindowClass);

        QMetaObject::connectSlotsByName(MainWindowClass);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindowClass)
    {
        MainWindowClass->setWindowTitle(QCoreApplication::translate("MainWindowClass", "MainWindow", nullptr));
        action_drawLines->setText(QCoreApplication::translate("MainWindowClass", "\347\273\230\345\210\266\347\233\264\347\272\277", nullptr));
        action_clear->setText(QCoreApplication::translate("MainWindowClass", "\346\270\205\347\251\272", nullptr));
        action_undo->setText(QCoreApplication::translate("MainWindowClass", "\346\222\244\351\224\200", nullptr));
        action_selectLine->setText(QCoreApplication::translate("MainWindowClass", "\351\200\211\346\213\251\347\272\277\346\256\265", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindowClass: public Ui_MainWindowClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
