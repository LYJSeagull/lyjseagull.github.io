#include "glview.h"

GLView::GLView(QWidget* parent)
    : QOpenGLWidget{ parent }
{
}

GLView::~GLView()
{
    makeCurrent();
    delete m_model;

    doneCurrent();
}

void GLView::initializeGL()
{
    initializeOpenGLFunctions();
    glEnable(GL_DEPTH_TEST);
    //glEnable(GL_CULL_FACE);
    /*glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);*/

    initShader(m_lightShader);

    m_model = new Model(this);
    m_camera.lastFrame = QTime::currentTime().msecsSinceStartOfDay() / 1000.0;

    initWorkPlane();
    //m_viewMat.lookAt(QVector3D(0, 0, 5), QVector3D(0, 0, 0), QVector3D(0, 1, 0));
}

void GLView::resizeGL(int w, int h)
{
    glViewport(0, 0, w, h);

    m_camera.SCR_WIDTH = w;
    m_camera.SCR_HEIGHT = h;

    m_projectionMat.setToIdentity();
    m_projectionMat.perspective(/*qDeg
reesToRadians*/(m_camera.Zoom), (float)m_camera.SCR_WIDTH / (float)m_camera.SCR_HEIGHT, 0.1f, 100.0f);
    //m_projectionMat.perspective(45.0f, (float)w / h, 0.1f, 100.0f);
}

void GLView::paintGL()
{
    glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    float currentFrame = QTime::currentTime().msecsSinceStartOfDay() / 1000.0;
    m_camera.deltaTime = currentFrame - m_camera.lastFrame;
    m_camera.lastFrame = currentFrame;

    m_lightShader.bind();

    m_viewMat = m_camera.GetViewMatrix();
    //m_viewMat.lookAt(QVector3D(0, 0, 5), QVector3D(0, 0, 0), QVector3D(0, 1, 0));

    m_lightShader.setUniformValue("projection", m_projectionMat);
    m_lightShader.setUniformValue("view", m_viewMat);
    m_lightShader.setUniformValue("model", m_modelMat);

    m_model->Draw(m_lightShader);
    m_workPlane->drawPlane();

    m_lightShader.release();
}

void GLView::initShader(QOpenGLShaderProgram& shader)
{
    bool result = true;
    //result = shader.addShaderFromSourceFile(QOpenGLShader::Vertex, ":/shader/1.model_loading.vert");
    result = shader.addShaderFromSourceCode(QOpenGLShader::Vertex, R"(
#version 450 core
layout (location = 0) in vec3 aPos;
layout (location = 1) in vec3 aColor;

out vec3 fragColor;
out vec2 screenPos;  // �����Ļ���꣨���ڽ��䣩

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;
uniform vec2 screenSize;  // ��Ļ����

void main() {
    gl_Position = projection * view * model * vec4(aPos, 1.0);
    fragColor = aColor;
    // ������Ļ���꣨��׼����0~1��Χ��
    screenPos = (gl_Position.xy / gl_Position.w + 1.0) * 0.5;
}
    )");

    if (!result) {
        qDebug() << shader.log();
    }
    //result = shader.addShaderFromSourceFile(QOpenGLShader::Fragment, ":/shader/1.model_loading.frag");
    result = shader.addShaderFromSourceCode(QOpenGLShader::Fragment, R"(
    #version 450 core
in vec3 fragColor;
in vec2 screenPos;  // ������Ļ����
out vec4 FragColor;

// ������ɫ������CAD�����ҽ��䣩
vec3 topColor = vec3(0.25f, 0.25f, 0.25f);  // ��������
vec3 bottomColor = vec3(0.15f, 0.15f, 0.15f);  // �ײ��԰�

void main() {
    // ����ģ��ʱ��ԭ����ɫ�������ý���ɫ����
    if (gl_FragCoord.z < 1.0) {  // ����������ģ�ͣ�zֵС��1��
        FragColor = vec4(fragColor, 1.0);
    } else {  // �����Ǳ���
        // ��Y�����ֵ���㽥����ɫ
        float t = screenPos.y;  // t=0�ǵײ���t=1�Ƕ���
        vec3 bgColor = mix(bottomColor, topColor, t);
        FragColor = vec4(bgColor, 1.0);
    }
}    )");
    if (!result) {
        qDebug() << shader.log();
    }
    result = shader.link();
    if (!result) {
        qDebug() << shader.log();
    }
}

bool GLView::event(QEvent* e)
{
    makeCurrent();

    if (m_camera.handle(e))
        update();

    doneCurrent();
    return QWidget::event(e);
}

void GLView::initWorkPlane()
{
    PlanePara para;
    para.origin = QVector3D(0.0f, -1.0f, 0.0f);//ԭ��
    para.normal = QVector3D(0.0f, 1.0f, 0.0f); //����
    para.halfLength = 15.0f;
    para.gridCntPerEdge = 12;
    para.offset = 0.0f;

    m_workPlane = new WorkPlane();
    m_workPlane->initPlane(para);
}