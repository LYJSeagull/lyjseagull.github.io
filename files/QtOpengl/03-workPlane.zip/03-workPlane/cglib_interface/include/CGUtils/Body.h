﻿#ifndef __Body_H__
#define __Body_H__

#include "Face.h"
namespace CGUTILS
{
    class CGLIB_EXPORTS Body
    {
    public:
        vector<Face> lstFace;
    };
}
#endif
