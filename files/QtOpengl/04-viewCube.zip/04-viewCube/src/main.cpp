#include "MainWindow.h"
#include <QtWidgets/QApplication>
#include "viewSetting.h"

#pragma comment(lib, "../cglib_interface/bin/win64/Release/CGLib.lib")

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    
    ViewerSetting::devicePixelRatio = QGuiApplication::primaryScreen()->devicePixelRatio();

    MainWindow window;
    window.show();
    return app.exec();
}
