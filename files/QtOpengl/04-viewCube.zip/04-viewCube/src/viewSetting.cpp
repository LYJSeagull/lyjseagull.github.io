#include "viewSetting.h"

float ViewerSetting::devicePixelRatio = 1.0;
