#pragma once
#include <qopenglwidget.h>
#include <qopenglfunctions_4_5_core.h>
#include <qopenglshaderprogram.h>

#include "model.h"

class GLView : public QOpenGLWidget, QOpenGLFunctions_4_5_Core
{
	Q_OBJECT
public:
	explicit GLView(QWidget* parent = nullptr);

protected:
	virtual void initializeGL();
	virtual void resizeGL(int w,int h);
	virtual void paintGL();

private:
	bool initShader(QOpenGLShaderProgram& shader);

private:
	Model* m_model{ nullptr };
	QOpenGLShaderProgram m_shader;

signals:

};