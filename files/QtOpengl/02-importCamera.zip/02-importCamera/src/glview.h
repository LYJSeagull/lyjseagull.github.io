#pragma once
#include <qopenglwidget.h>
#include <qopenglfunctions_4_5_core.h>
#include <qopenglshaderprogram.h>
#include <QMouseEvent>

#include "model.h"
#include "camera.h"

class GLView : public QOpenGLWidget, QOpenGLFunctions_4_5_Core
{
	Q_OBJECT
public:
	explicit GLView(QWidget* parent = nullptr);
	~GLView();

protected:
	virtual void initializeGL();
	virtual void resizeGL(int w,int h);
	virtual void paintGL();
	virtual bool event(QEvent* e);

private:
	void initShader(QOpenGLShaderProgram& shader);

private:
	Model* m_model{ nullptr };
	Camera m_camera = Camera(this, QVector3D(0.0f, 0.0f, 5.0f));

	//mvp����
	QMatrix4x4 m_modelMat;//�Զ�Ϊ��λ��
	QMatrix4x4 m_viewMat;
	QMatrix4x4 m_projectionMat;

	//��ɫ������
	QOpenGLShaderProgram m_lightShader;

signals:

};