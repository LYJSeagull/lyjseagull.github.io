#include "glview.h"

GLView::GLView(QWidget* parent)
    : QOpenGLWidget{ parent }
{
}

GLView::~GLView()
{
    makeCurrent();
    delete m_model;

    doneCurrent();
}

void GLView::initializeGL()
{
    initializeOpenGLFunctions();
    initShader(m_lightShader);

    m_model = new Model(this);
    m_camera.lastFrame = QTime::currentTime().msecsSinceStartOfDay() / 1000.0;

    //m_viewMat.lookAt(QVector3D(0, 0, 5), QVector3D(0, 0, 0), QVector3D(0, 1, 0));
}

void GLView::resizeGL(int w, int h)
{
    glViewport(0, 0, w, h);

    m_camera.SCR_WIDTH = w;
    m_camera.SCR_HEIGHT = h;

    m_projectionMat.setToIdentity();
    m_projectionMat.perspective(/*qDeg
reesToRadians*/(m_camera.Zoom), (float)m_camera.SCR_WIDTH / (float)m_camera.SCR_HEIGHT, 0.1f, 100.0f);
    //m_projectionMat.perspective(45.0f, (float)w / h, 0.1f, 100.0f);
}

void GLView::paintGL()
{
    glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    float currentFrame = QTime::currentTime().msecsSinceStartOfDay() / 1000.0;
    m_camera.deltaTime = currentFrame - m_camera.lastFrame;
    m_camera.lastFrame = currentFrame;

    m_lightShader.bind();

    m_viewMat = m_camera.GetViewMatrix();
    //m_viewMat.lookAt(QVector3D(0, 0, 5), QVector3D(0, 0, 0), QVector3D(0, 1, 0));

    m_lightShader.setUniformValue("projection", m_projectionMat);
    m_lightShader.setUniformValue("view", m_viewMat);
    m_lightShader.setUniformValue("model", m_modelMat);

    m_model->Draw(m_lightShader);
    m_lightShader.release();
}

void GLView::initShader(QOpenGLShaderProgram& shader)
{
    bool result = true;
    //result = shader.addShaderFromSourceFile(QOpenGLShader::Vertex, ":/shader/1.model_loading.vert");
    result = shader.addShaderFromSourceCode(QOpenGLShader::Vertex, R"(
#version 450 core
layout (location = 0) in vec3 aPos;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(aPos, 1.0);
}
    )");

    if (!result) {
        qDebug() << shader.log();
    }
    //result = shader.addShaderFromSourceFile(QOpenGLShader::Fragment, ":/shader/1.model_loading.frag");
    result = shader.addShaderFromSourceCode(QOpenGLShader::Fragment, R"(
    #version 450 core
out vec4 FragColor;

uniform vec4 objectColor; //��CPU�˶�Ӧ��ȫ��uniform����

void main()
{    
    FragColor = objectColor;
}
    )");
    if (!result) {
        qDebug() << shader.log();
    }
    result = shader.link();
    if (!result) {
        qDebug() << shader.log();
    }
}

bool GLView::event(QEvent* e)
{
    makeCurrent();

    if (m_camera.handle(e))
        update();

    doneCurrent();
    return QWidget::event(e);
}

