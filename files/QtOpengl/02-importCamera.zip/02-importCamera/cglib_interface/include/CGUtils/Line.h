﻿#ifndef __LINE_H__
#define __LINE_H__

#include "Vector3.h"
namespace CGUTILS
{
    class CGLIB_EXPORTS Line
    {
    public:
        Vector3f pt0;
        Vector3f pt1;
    };
}
#endif
